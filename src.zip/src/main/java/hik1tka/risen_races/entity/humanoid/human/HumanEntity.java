package hik1tka.risen_races.entity.humanoid.human;

import hik1tka.risen_races.RisenRaces;
import hik1tka.risen_races.entity.humanoid.HumanoidEntity;
import hik1tka.risen_races.entity.humanoid.data.ProfessionDefinition;
import hik1tka.risen_races.util.IGenderedEntity;
import hik1tka.risen_races.register.ModSounds;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.*;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.village.TradeOffer;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class HumanEntity extends HumanoidEntity implements IGenderedEntity {
    public static final EntityType<HumanEntity> HUMAN = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(RisenRaces.MOD_ID, "human"),
            FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, HumanEntity::new)
                    .dimensions(EntityDimensions.changing(0.6f, 1.8f))
                    .build()
    );

    public static net.minecraft.entity.attribute.DefaultAttributeContainer.Builder createHumanAttributes() {
        // Береш з HumanoidEntity, а не з VillagerEntity - HumanEntity з ним не споріднений.
        return HumanoidEntity.createHumanoidAttributes();
    }

    private static final TrackedData<Integer> SKIN_ID = DataTracker.registerData(HumanEntity.class, TrackedDataHandlerRegistry.INTEGER);

    public HumanEntity(EntityType<? extends HumanoidEntity> entityType, World world) {
        super(entityType, world);
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(SKIN_ID, 0);
        // Стать НЕ рандомізуємо тут - initDataTracker() виконується і на
        // клієнті (для кожної локальної "примарної" копії ентіті), а не
        // тільки на сервері. Рандомний setFemale() тут створював стан, коли
        // клієнтська копія на мить мала СВОЄ власне випадкове isFemale,
        // не синхронізоване з сервером ще - і якщо звук встигав програтись
        // саме в цю мить, лунала не та стать. Реальна стать вирішується
        // один раз, тільки на сервері, у initialize() нижче.
    }

    @Override
    protected void afterUsing(TradeOffer offer) {

    }

    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, @Nullable EntityData entityData, @Nullable NbtCompound entityNbt) {
        this.setRace(hik1tka.risen_races.entity.humanoid.HumanoidRace.HUMAN);

        // Стать вирішується тут, а не в initDataTracker() - цей метод
        // гарантовано виконується лише на сервері й лише один раз за спавн.
        this.setFemale(this.random.nextBoolean());
        this.rollSkinForGender();

        return super.initialize(world, difficulty, spawnReason, entityData, entityNbt);
    }

    /**
     * Рандомізує SkinId відповідно до поточної статі (isFemale()).
     * Викликається і при природному спавні (initialize), і для дітей,
     * народжених через HumanoidEntity#breedWith (onBabyCreated).
     */
    private void rollSkinForGender() {
        if (this.isFemale()) {
            // Жіночі скіни: 0..11 (всього 12 скінів)
            this.setSkinId(this.random.nextInt(12));
        } else {
            // Чоловічі скіни: 0..9 (всього 10 скінів)
            this.setSkinId(this.random.nextInt(10));
        }
    }

    @Override
    protected void onBabyCreated(hik1tka.risen_races.entity.humanoid.HumanoidEntity baby) {
        // На момент виклику цього хука стать дитини (setFemale) вже виставлена
        // в breedWith(), тому тут просто підбираємо скін під неї.
        if (baby instanceof HumanEntity human) {
            human.rollSkinForGender();
        }
    }

    @Override
    public @Nullable PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return this.isFemale() ? ModSounds.FEMALE_AMBIENT : ModSounds.MALE_AMBIENT;
    }

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        if (!this.isFemale() && this.random.nextInt(1000) == 0) {
            return ModSounds.MALE_NO_GOD;
        }
        return this.isFemale() ? ModSounds.FEMALE_HURT : ModSounds.MALE_HURT;
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.ENTITY_DEATH;
    }

    @Override
    protected SoundEvent getTradingSound(boolean sold) {
        if (!sold) {
            return this.isFemale() ? super.getTradingSound(false) : ModSounds.MALE_NO;
            // Коли буде готовий звук для жінки, розкоментуй:
            // return this.isFemale() ? ModSounds.FEMALE_NO : ModSounds.MALE_NO;
        }
        return super.getTradingSound(sold);
    }

    public int getSkinId() {
        return this.dataTracker.get(SKIN_ID);
    }

    @Override
    public float getScaleFactor() {
        return this.isBaby() ? 0.7f : 1.0f;
    }

    public void setSkinId(int id) {
        this.dataTracker.set(SKIN_ID, id);
    }

    /**
     * Замість звичайної смерті від зомбі-подібного нападника - шанс
     * конвертації в підвид ZombifiedHumanEntity (звичайний/кадавр/утопець -
     * залежно від біома, див. ZombieVariantHelper) зі збереженням статі/
     * скіна/імені/віку/професії в MD_NPC_Memory.
     *
     * Сам шанс перетворення (а не гарантована смерть) залежить від
     * складності світу - як зараження жителя ваніллю: легка 0% (завжди
     * звичайна смерть), середня 50%, складна 100% (завжди перетворення).
     */
    @Override
    public boolean damage(DamageSource source, float amount) {
        if (!this.getWorld().isClient
                && amount >= this.getHealth()
                && source.getAttacker() instanceof net.minecraft.entity.mob.ZombieEntity
                && this.getWorld() instanceof net.minecraft.server.world.ServerWorld serverWorld) {

            float chance = getZombificationChance(serverWorld.getDifficulty());
            if (this.random.nextFloat() < chance) {
                tryZombify(serverWorld);
                return true; // "пошкодження оброблено" - справжньої смерті не відбувається
            }
            // не пощастило - людина помирає як зазвичай, падаємо в super.damage() нижче
        }
        return super.damage(source, amount);
    }

    /**
     * Шанс перетворення на зомбі при смертельному ударі зомбі - як у
     * ванільному зараженні жителів, прив'язано до Difficulty світу (НЕ до
     * регіональної local difficulty, яка ще й від відстані/часу залежить -
     * тут навмисно проста прив'язка тільки до глобального рівня складності).
     */
    private static float getZombificationChance(net.minecraft.world.Difficulty difficulty) {
        return switch (difficulty) {
            case PEACEFUL, EASY -> 0.0f;
            case NORMAL -> 0.5f;
            case HARD -> 1.0f;
        };
    }

    private void tryZombify(net.minecraft.server.world.ServerWorld world) {
        hik1tka.risen_races.util.ZombieVariant variant =
                hik1tka.risen_races.util.ZombieVariantHelper.resolveVariant(world, this);
        hik1tka.risen_races.entity.zombie.ZombifiedHumanEntity zombie =
                hik1tka.risen_races.util.ZombieVariantHelper.create(world, variant);
        if (zombie == null) return;

        zombie.refreshPositionAndAngles(this.getX(), this.getY(), this.getZ(), this.getYaw(), this.getPitch());
        zombie.setFemale(this.isFemale());
        zombie.setProfession(this.getProfession());

        net.minecraft.nbt.NbtCompound memory = new net.minecraft.nbt.NbtCompound();
        memory.putBoolean("WasFemale", this.isFemale());
        memory.putInt("SkinID", this.getSkinId());
        memory.putString("Profession", this.getProfession());
        memory.putBoolean("IsBaby", this.isBaby());
        memory.putString("StoredName", this.hasCustomName() ? this.getCustomName().getString() : "");
        zombie.setNpcMemory(memory);

        world.spawnEntity(zombie);
        this.discard();
    }

    @Override
    public java.util.List<hik1tka.risen_races.entity.humanoid.data.ProfessionDefinition> getAvailableProfessions() {
        return java.util.List.of(
                new ProfessionDefinition("farmer", net.minecraft.world.poi.PointOfInterestTypes.FARMER, 48),
                new ProfessionDefinition("butcher", net.minecraft.world.poi.PointOfInterestTypes.BUTCHER, 48),
                new ProfessionDefinition("shepherd", net.minecraft.world.poi.PointOfInterestTypes.SHEPHERD, 48),
                new ProfessionDefinition("fisherman", net.minecraft.world.poi.PointOfInterestTypes.FISHERMAN, 48),
                new ProfessionDefinition("leatherworker", net.minecraft.world.poi.PointOfInterestTypes.LEATHERWORKER, 48),
                new ProfessionDefinition("cleric", net.minecraft.world.poi.PointOfInterestTypes.CLERIC, 48),
                new ProfessionDefinition("cartographer", net.minecraft.world.poi.PointOfInterestTypes.CARTOGRAPHER, 48),

                new hik1tka.risen_races.entity.humanoid.data.ProfessionDefinition(
                        "builder", net.minecraft.world.poi.PointOfInterestTypes.MASON, 48)
        );
    }

    // TODO: getProfession() приберено — getVillagerData() існує лише у VillagerEntity,
    // якого HumanoidEntity не наслідує. Коли зробиш власну систему професій,
    // додай сюди свій метод (наприклад через ще один TrackedData<String>).

    public float getScaleModifier() {
        return this.isFemale() ? 0.95f : 1.0f;
    }

    @Override
    public String getRaceId() {
        // Похідне від getRace() з HumanoidEntity, а не окремий хардкод -
        // одне джерело правди для раси.
        return this.getRace().name().toLowerCase(java.util.Locale.ROOT);
    }

    // isFemale()/setFemale() тепер повністю успадковані від HumanoidEntity -
    // окремо не перевизначаємо, щоб не було двох джерел правди.

    @Override
    public boolean isInLove() {
        return false;
    }

    @Override
    public void setLoveTicks(int ticks) {
        // Не використовується: люди не мають "закоханості" від їжі гравцем,
        // як і звичайні жителі — розмноження повністю автоматичне (ваніль).
    }

    @Override
    public boolean canBreedWith(PassiveEntity other) {
        return this.canBreedWithGendered(other);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("SkinId", this.getSkinId());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("SkinId")) {
            this.setSkinId(nbt.getInt("SkinId"));
        }
    }
}