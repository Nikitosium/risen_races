package hik1tka.risen_races;

import hik1tka.risen_races.register.ModEffect;
import hik1tka.risen_races.register.ModEntity;
import hik1tka.risen_races.register.ModItem;
import hik1tka.risen_races.register.ModSounds;
import hik1tka.risen_races.register.ModVillagerReplacement;
import hik1tka.risen_races.register.ModZombieReplacement;
import net.fabricmc.api.ModInitializer;

import net.minecraft.util.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RisenRaces implements ModInitializer {
    public static final String MOD_ID = "risen_races";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    //Initialise registry
    @Override
    public void onInitialize() {
        LOGGER.info("Mod has been initialised");

        ModEffect.registerModEffect();
        ModEffect.registerEffects();
        ModItem.registerModItem();
        ModEntity.registerModEntity();
        ModSounds.registerSounds();
        ModVillagerReplacement.register();
        ModZombieReplacement.register();
    }

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }
}